//配置文件vue-cli 90%都是webpack配置

module.exports = {
    devServer:{
        proxy:{
            //配置代理
            "/x":{
                //凡是以"/x"开头的请求进行代理
                target:'https://api.bilibili.com',
                onProxyReq(proxyReq){
                    proxyReq.setHeader('origin','https://www.bilibili.com');
                    proxyReq.setHeader('referer','https://www.bilibili.com/v/channel');
                }
            }
        }
    }
}
