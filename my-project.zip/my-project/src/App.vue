<template>
<div>
  <div>
    <div style="width:250px">
      <Title-menu :isActive="true" >
        <template v-slot:title>
          发现频道
        </template>
        <template v-slot:icon>
          >
        </template>
      </Title-menu>

      <channel-list
       :data="cList" 
       :activeId = "activeId1" 
       style="width:250px;"
       @handleClick = "updateId"
       :columns = '3'
       ></channel-list>

    </div>
    
  </div>
</div>
</template>

<script>
import TitleMenu from './components/TitleMenu.vue';
import ChannelList from './components/ChannelList.vue';
export default {
  components: { 
    TitleMenu,
    
    ChannelList,
    
  },
  data () {
    return {
      selectTitle:true,
      activeId1:1,
      cList :[
      {id:1,name:'动漫',num:'11'},
      {id:2,name:'动漫',num:'22'},
      {id:3,name:'动漫',num:'33'},
      {id:4,name:'动漫',num:'44'},
      {id:5,name:'动漫',num:'55'},
      {id:6,name:'动漫',num:'66'},
      {id:7,name:'动漫',num:'77'},
      {id:8,name:'动漫',num:'88'},
      ],
    }
  },
  methods: {
    updateId(e){
      // this.activeId1 = event;
      console.log(e);
      this.activeId1 = e;
    }
  }
};
</script>

<style scoped>

</style>
