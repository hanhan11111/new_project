<template>
<div class="channelList"  >
    <div 
    v-for="item in data" 
    :key="item.id"
    :style="{width:'50%'}"
     >
        <channel 
        :isActive = "activeId === item.id" 
        
        :data = {name:item.name,num:item.num}
         @handleClick="$emit('handleClick',item.id)"
        ></channel>

    </div>
</div>
  
</template>

<script>
import Channel from './Channel.vue'

export default {
   props: {
       data:{
           type:Array,
       },
       activeId:{
           type:Number,
       },
       columns:{
           type:Number,
       },
   },
    components: {
        Channel,
    },
}

</script>

<style>
.channelList{
    width: 100%;
    float: left;
}
</style>