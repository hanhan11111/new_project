<template>
    <div class="item" :class={active:isActive} @click="$emit('handleClick')">
        <!-- 插槽 -->
        <slot></slot>
    </div>
</template>

<script>
export default {
    props:{
        isActive:{
            type:Boolean,//约束类型
            required:true,//约束是否必填
        },
    },
    methods: {
        handleClick(){
            this.$emit('handleClick',this.isActive);
            console.log(this.isActive);
        },
    },
}
</script>

<style scoped>
    .item{
     /* 设置组件宽高和父元素相同 而不是内容撑开 */
        cursor:pointer;
        width: 100%;
        height: 100%;
        overflow: hidden;
    }
    .active{
        background-color:#f1efef;
    }
    .item:hover{
        background-color:#f4f4f4;
    }
</style>>
   