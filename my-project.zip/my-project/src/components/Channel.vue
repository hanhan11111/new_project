<template>
<div>
  <div class="channel"  @click="$emit('handleClick')">
    <Item :isActive = "isActive" >
        <div class="inner">
           <span class="name">{{data.name}}</span>
           <span class="number">{{data.num}}</span>
           
        </div>
    </Item>
  </div>

  <div>
      <slot></slot>
  </div>
</div>

</template>

<script>
import Item from './item'
export default {
    props: {
        isActive:{
            type:Boolean,
            default:false,//默认值
        },
       data:{
           type:Object,
       }
    },
    components: {
        Item,
    },
    methods: {
    handleClick(){
        this.$emit('handleClick',this.isActive);
        console.log(this.isActive);
    },  
    }
}
</script>

<style scoped>

.inner{
    padding: 0 20px;
}
.channel{
  width:100%;
  height: 40px;
  line-height: 40px;
}
</style>