<template>
<div>
  <div class="title-menu" >
    <Item :isActive = "select" @handleClick ="$emit('handleClick',select)">
        <div class="inner">
            <div class="left">
                <slot name='title'></slot>
            </div>
            <div class="right">
                 <slot name='icon'></slot>
            </div>
        </div>
    </Item>
  </div>

  <div>
      <slot></slot>
  </div>
</div>

</template>

<script>
import Item from './item'
export default {
    props: {
        select:{
            type:Boolean,
            default:false,//默认值
        }
    },
    components: {
        Item,
    }
}
</script>

<style scoped>
.left{
    float: left;
    color: #212121;
    font-weight: 500;
}
.right{
    float: right;
    font-size: 12px;
    color: #999;

}
.inner{
    padding: 0 20px;
}
.title-menu{
  width:100%;
  height: 46px;
  line-height: 46px;
}
</style>